`example.php` script uses PHP XLS Excel Parser and its documentation to output `example.xls` file contents.  
In order for it to work, you should put `MSXLS.php` and `MSCFB.php` in the same folder as `example.php` and `example.xls`.
