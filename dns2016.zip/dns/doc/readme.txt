
       Please note:
       Accessing the server from clients requires firewall rules.
       The installer has NOT touched your firewall rules.
       Please verify and run firewall.bat from installation
       folder or setup your individual rules for the server.


haneWIN DNS Server Updates:

2.0.16  bugs in language translation, fixed
2.0.15  cache limit for address records added
2.0.14  bug in CNAME to external domains, fixed
2.0.13  support for SRV records added
2.0.12  gatway status after system resume fixed
2.0.10  dynamic interface update added
2.0.8   initial setup improved
2.0.7	bug in blocklist handling fixed
2.0.6   bug in Gateway dialog fixed
2.0.5	bug in blocklist handling fixed
2.0.4   loading large blocklists improved
2.0.3   service gui can run without elevation
        performance on cache and block list improved
2.0.2   server changes
2.0.1   serial update, fixed
2.0.0   dns-over-tls added
        control of default gateway added

1.6.3   selective binding to local ip addresses added
1.6.1   fixes/modifications in UI
1.6.0   support for block lists added

1.5.5   wildcard entry for CNAME enabled
1.5.4   crash on zero length names fixed
1.5.3   dnscmd remove operation added
1.5.1   languages implementation replaced, dll -> ini, an Editor or TransTool
        from PDF Creator could be used for setting up new translations
1.5     native x64 version added

1.4.10	icon display on Win 7 x64 fixed
1.4.9   automatic entries for local IP addresses added
1.4.8   name for local domain changed to a required entry
1.4.7   malformed NS entry crashed server, fixed
1.4.6   internal changes
1.4.5   buffer overflow on zone transfer, fixed
1.4.4   bug in version 1.4.3 changes, fixed
1.4.3   reply packet too long could cause server crash, fixed
1.4.2   automatic external server address configuration added
1.4.1   license key not saved, fixed
1.4     UI rewritten, support of multiple applet instances implemented

1.3.15	bug in domain modification fixed
1.3.13  log option added
1.3.12  update time interval corrected
1.3.11  caching of PTR records fixed
1.3.10  log added
1.3.9   bug in ttl caching fixed
1.3.8
1.3.6   internal changes
1.3.5   caching of CNAME records fixed
        caching of repeated A, NS, MX names added
1.3.4   handling of MX wildcard records corrected
        CNAME checks added, handling improved
1.3.3   Response to SOA queries improved
1.3.2   CriticalSection mismatch on refused zone transfer, fixed
1.3.1   Loading access control fixed
1.3     Dynamic Update 
	Primaray/Secondary Server 
        Security features improved

1.2.2	Support for language modules
1.2.1   name with more than one address, fixed
1.2     Control Panel Applet added

1.1.6   bug in type=any responses, fixed
1.1.5   bug in udp server, fixed
1.1.4   service mode improved
1.1.3   bug in adding CNAME, fixed
1.1.2   bug in caching, fixed
1.1.1   forwarding improved
1.1     caching implemented

1.0     first release

